﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Common
{
    public static class CoreConstants
    {
        public static string CognitiveServicesRegion = "westus";
        public static string CustomVisionServicesRegion = "southcentralus";
        public static string CognitiveServicesBaseUrl = $"https://{CognitiveServicesRegion}.api.cognitive.microsoft.com";
        public static string SearchServicesBaseUrl = $"https://api.cognitive.microsoft.com";
        public static string VideoIndexerBaseUrl =
            "https://videobreakdown.azure-api.net/Breakdowns/Api/Partner/Breakdowns";

        public static string CustomVisionBaseUrl = $"https://{CustomVisionServicesRegion}.api.cognitive.microsoft.com/customvision/v1.0/";

    }
}
