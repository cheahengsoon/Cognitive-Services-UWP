﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.Translation
{
    public class DeciperResult
    {
        public int ec { get; set; }
        public string em { get; set; }
        public string sentence { get; set; }
    }

}
