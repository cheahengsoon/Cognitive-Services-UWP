﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.Translation.Common
{
    public enum AccessTokenType { Text, Speech }
    public enum GenderType { Female, Male}
}
