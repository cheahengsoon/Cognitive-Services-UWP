﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.VideoIndexer
{
    public class VideoUploadStatusInfo
    {
        public string state { get; set; }
        public string progress { get; set; }
    }

}
