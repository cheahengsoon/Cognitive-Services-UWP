﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.VideoIndexer.Common
{
    public enum VideoPrivacyType { Public, Private }
    public enum VideoUploadStatusType { Uploaded, Processing, Processed, Failed }
}
