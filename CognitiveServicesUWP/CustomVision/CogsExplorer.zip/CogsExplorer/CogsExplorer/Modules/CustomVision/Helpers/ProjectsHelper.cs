﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Web.Http;

namespace CogsExplorer.Modules.CustomVision.Helpers
{
    public static class ProjectsHelper
    {
        public static async Task<List<ProjectInformation>> GetProjectsAsync()
        {
            List<ProjectInformation> projects = new List<ProjectInformation>();

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                    Common.CoreConstants.CustomVisionApiTrainingKey);

                var uri = new Uri(
                    $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects");

                try
                {
                    var response = await client.GetAsync(uri);

                    var content = await response.Content.ReadAsStringAsync();

                    var results = JsonConvert.DeserializeObject<List<ProjectInfo>>(content);

                    projects = (from result in results
                                select new ProjectInformation()
                                {
                                    Id = result.Id,
                                    DisplayName = result.Name,
                                    ThumbnailUrl = result.ThumbnailUri,

                                }).ToList();


                }
                catch (Exception ex)
                {

                }
            }

            return projects;
        }
    }
}
