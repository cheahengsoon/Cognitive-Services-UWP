﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.CustomVision.Helpers
{
    public static class PickerHelper
    {

        public static async Task<ImageInformation> SelectImageAsync()
        {
            ImageInformation image = null;

            var picker =
                new Windows.Storage.Pickers.FileOpenPicker
                {
                    ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail,
                    SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.PicturesLibrary
                };

            picker.FileTypeFilter.Add(".jpg");
            picker.FileTypeFilter.Add(".jpeg");
            picker.FileTypeFilter.Add(".png");

            var file = await picker.PickSingleFileAsync();
            
            image = new ImageInformation()
            {
                DisplayName = file.DisplayName,
                FileBytes = await file.AsByteArrayAsync(),
                Url = file.Path,

            };

            return image;
        }

        public static async Task<List<ImageInformation>> SelectImagesAsync()
        {
            List<ImageInformation> images = new List<ImageInformation>();

            var picker =
                new Windows.Storage.Pickers.FileOpenPicker
                {
                    ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail,
                    SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.PicturesLibrary
                };

            picker.FileTypeFilter.Add(".jpg");
            picker.FileTypeFilter.Add(".jpeg");
            picker.FileTypeFilter.Add(".png");

            var files = await picker.PickMultipleFilesAsync();

            foreach (var file in files)
            {
                images.Add(new ImageInformation()
                {
                    DisplayName = file.DisplayName,
                    FileBytes = await file.AsByteArrayAsync(),
                    Url = file.Path,

                });
            }

            return images;
        }
    }
}
