﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Web.Http;

namespace CogsExplorer.Modules.CustomVision.Helpers
{
    public static class TrainingHelper
    {
        public static async Task<List<ImageInformation>> GetTaggedImagesAsync(string projectId, IEnumerable<TagInformation> tags)
        {
            List<ImageInformation> allImages = new List<ImageInformation>();

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                Common.CoreConstants.CustomVisionApiTrainingKey);

                var uri = new Uri(
                 $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/images/tagged/all?take=50&skip=0");

                try
                {
                    var response = await client.GetAsync(uri);
                    var content = await response.Content.ReadAsStringAsync();

                    if (response.StatusCode == HttpStatusCode.Ok)
                    {
                        var results = JsonConvert.DeserializeObject<List<TaggedImageInfo>>(content);

                        allImages = (from image in results
                                     select new ImageInformation()
                                     {
                                         Id = image.Id,
                                         DisplayName = image.Id,
                                         IsTagged = true,
                                         Url = image.ThumbnailUri,
                                         Predictions = GetPredictionsFromLabels(image.Labels, tags),


                                     }).ToList();
                    }

                }
                catch (Exception ex)
                {

                }

                return allImages;
            }
        }

        private static ObservableCollection<PredictionInformation> GetPredictionsFromLabels(Label[] labels, IEnumerable<TagInformation> tags)
        {
            ObservableCollection<PredictionInformation> predictions = new ObservableCollection<PredictionInformation>();

            foreach (var label in labels)
            {
                predictions.Add(new PredictionInformation()
                {
                    Tag = tags.FirstOrDefault(w => w.Id.Equals(label.TagId)).DisplayName,
                    TagId = label.TagId,
                    Probablity = 1.0,
                });
            }

            return predictions;
        }

        public static async Task<bool> SetDefaultIterationAsync(string projectId)
        {
            bool successful = false;

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                Common.CoreConstants.CustomVisionApiTrainingKey);

                var uri = new Uri(
                 $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/iterations");

                try
                {
                    var response = await client.GetAsync(uri);
                    var content = await response.Content.ReadAsStringAsync();

                    if (response.StatusCode == HttpStatusCode.Ok)
                    {
                        var iterations = JsonConvert.DeserializeObject<List<IterationResult>>(content);

                        var latestIteration = iterations.OrderByDescending(o => o.TrainedAt).FirstOrDefault();

                        uri = new Uri($"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/iterations/{latestIteration.Id}");

                        latestIteration.IsDefault = true;

                        var message = new HttpRequestMessage(HttpMethod.Patch, uri);

                        message.Content = new HttpStringContent(JsonConvert.SerializeObject(latestIteration), Windows.Storage.Streams.UnicodeEncoding.Utf8, "application/json");

                        response = await client.SendRequestAsync(message);

                        content = await response.Content.ReadAsStringAsync();

                        successful = true;
                    }

                }
                catch (Exception ex)
                {

                }

                return successful;
            }
        }

        public static async Task<bool> TrainProjectAsync(string projectId)
        {
            bool successful = false;

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                    Common.CoreConstants.CustomVisionApiTrainingKey);

                var uri = new Uri(
                    $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/train");

                try
                {
                    var response = await client.PostAsync(uri, null);

                    var content = await response.Content.ReadAsStringAsync();

                    var result = JsonConvert.DeserializeObject<TrainingResult>(content);

                    string iterationId = result.Id;

                    successful = result.Status.Equals("Training");

                    while (true)
                    {
                        await Task.Delay(1000);

                        var iteration = await Helpers.TrainingHelper.GetIterationAsync(projectId, iterationId);

                        if (iteration.Status.Equals("Completed")) break;
                    }

                }
                catch (Exception ex)
                {

                }
            }

            return successful;
        }

        private static async Task<IterationResult> GetIterationAsync(string projectId, string iterationId)
        {
            IterationResult iteration = null;

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                Common.CoreConstants.CustomVisionApiTrainingKey);

                var uri = new Uri(
                 $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/iterations/{iterationId}");

                try
                {
                    var response = await client.GetAsync(uri);
                    var content = await response.Content.ReadAsStringAsync();

                    if (response.StatusCode == HttpStatusCode.Ok)
                    {
                        iteration = JsonConvert.DeserializeObject<IterationResult>(content);
                    }

                }
                catch (Exception ex)
                {

                }

                return iteration;
            }
        }

        public static async Task<bool> UploadImagesAsync(string projectId, List<byte[]> images, IEnumerable<string> tagIds)
        {
            bool successful = false;

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                Common.CoreConstants.CustomVisionApiTrainingKey);

                string tagIdParameters = string.Empty;

                foreach (var tagId in tagIds.Take(5))
                {
                    tagIdParameters += $"tagIds={tagId}&";
                }

                var uri = new Uri(
                 $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/images/image?{tagIdParameters}");

                try
                {
                    var payload = new HttpMultipartFormDataContent();

                    foreach (var image in images)
                    {
                        payload.Add(new HttpBufferContent(image.AsBuffer()));
                    }

                    var response = await client.PostAsync(uri, payload);

                    var content = await response.Content.ReadAsStringAsync();

                }
                catch (Exception ex)
                {

                }
            }


            return successful;
        }

        public static async Task<List<TagInformation>> GetTagsAsync(string projectId)
        {
            List<TagInformation> allTags = new List<TagInformation>();

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                Common.CoreConstants.CustomVisionApiTrainingKey);

                var uri = new Uri(
                 $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/tags");

                try
                {
                    var response = await client.GetAsync(uri);
                    var content = await response.Content.ReadAsStringAsync();

                    if (response.StatusCode == HttpStatusCode.Ok)
                    {
                        var results = JsonConvert.DeserializeObject<TagCollection>(content);

                        allTags = (from tag in results.Tags
                                   select new TagInformation()
                                   {
                                       Id = tag.Id,
                                       DisplayName = tag.Name,
                                       ImageCount = tag.ImageCount,

                                   }).OrderBy(o => o.DisplayName).ToList();
                    }

                }
                catch (Exception ex)
                {

                }

                return allTags;
            }
        }

        public static async Task<List<TagInformation>> CreateTagsAsync(string projectId, List<string> tags)
        {
            List<TagInformation> allTags = new List<TagInformation>();

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Training-key",
                Common.CoreConstants.CustomVisionApiTrainingKey);

                foreach (var tag in tags)
                {

                    var uri = new Uri(
                     $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Training/projects/{projectId}/tags?name={tag}");

                    try
                    {
                        var response = await client.PostAsync(uri, null);
                        var content = await response.Content.ReadAsStringAsync();

                        if (response.StatusCode == HttpStatusCode.Ok)
                        {
                            var result = Newtonsoft.Json.JsonConvert.DeserializeObject<TagResult>(content);

                            allTags.Add(new TagInformation()
                            {
                                Id = result.Id,
                                DisplayName = result.Name,

                            });
                        }

                    }
                    catch (Exception ex)
                    {

                    }
                }
            }


            return allTags;
        }
    }
}
