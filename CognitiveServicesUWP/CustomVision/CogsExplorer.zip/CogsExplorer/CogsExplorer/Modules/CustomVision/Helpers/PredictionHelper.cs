﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;
using Windows.Web.Http;

namespace CogsExplorer.Modules.CustomVision.Helpers
{
    public static class PredictionHelper
    {
        public static async Task<List<PredictionInformation>> GetImagePredictionsAsync(string projectId, byte[] bytes)
        {
            List<PredictionInformation> predictions = new List<PredictionInformation>();

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Prediction-key",
                Common.CoreConstants.CustomVisionApiPredictionKey);

                var uri = new Uri(
                 $"{CogsExplorer.Common.CoreConstants.CustomVisionBaseUrl}Prediction/{projectId}/image");

                try
                {
                    var payload = new HttpMultipartFormDataContent();

                    payload.Add(new HttpBufferContent(bytes.AsBuffer()));

                    var response = await client.PostAsync(uri, payload);

                    var content = await response.Content.ReadAsStringAsync();

                    var prediction = JsonConvert.DeserializeObject<PredictionResult>(content);

                    predictions = (from item in prediction.Predictions.Where(w => w.Probability > 0.5)
                                   select new PredictionInformation()
                                   {
                                       TagId = item.TagId,
                                       Tag = item.Tag,
                                       Probablity = item.Probability,

                                   }).ToList();


                }
                catch (Exception ex)
                {

                }
            }

            return predictions;
        }
    }
}
