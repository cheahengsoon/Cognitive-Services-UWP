﻿using CogsExplorer.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.CustomVision
{
    public class PredictionInformation : ObservableBase
    {
        private string _tagId;
        public string TagId
        {
            get { return _tagId; }
            set { Set(ref _tagId, value); }
        }

        private string _tag;
        public string Tag
        {
            get { return _tag; }
            set { Set(ref _tag, value); }
        }

        private double _probablity;
        public double Probablity
        {
            get { return _probablity; }
            set { Set(ref _probablity, value); }
        }
    }
}
