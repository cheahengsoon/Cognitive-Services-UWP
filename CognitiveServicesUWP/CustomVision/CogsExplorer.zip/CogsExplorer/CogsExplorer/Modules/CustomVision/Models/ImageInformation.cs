﻿using CogsExplorer.Common;
using CogsExplorer.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.UI;
using Windows.UI.Xaml.Media;

namespace CogsExplorer.Modules.CustomVision
{
    public class ImageInformation : ObservableBase
    {
        private string _id;
        public string Id
        {
            get { return _id; }
            set { Set(ref _id, value); }
        }

        private string _displayName;
        public string DisplayName
        {
            get { return _displayName; }
            set { Set(ref _displayName, value); }
        }
       
        private byte[] _fileBytes;
        public byte[] FileBytes
        {
            get { return _fileBytes; }
            set { Set(ref _fileBytes, value); }
        }

        private string _url;
        public string Url
        {
            get { return _url; }
            set { Set(ref _url, value); }
        }

        private ObservableCollection<string> _tags = new ObservableCollection<string>();
        public ObservableCollection<string> Tags
        {
            get { return _tags; }
            set { Set(ref _tags, value); }
        }

        
        private ObservableCollection<PredictionInformation> _predictions = new ObservableCollection<PredictionInformation>();
        public ObservableCollection<PredictionInformation> Predictions
        {
            get { return _predictions; }
            set { Set(ref _predictions, value); }
        }

        private string _predictionsLabel;
        public string PredictionsLabel
        {
            get { return _predictionsLabel; }
            set { Set(ref _predictionsLabel, value); }
        }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { Set(ref _isSelected, value); }
        }

        private bool _isTagged;
        public bool IsTagged
        {
            get { return _isTagged; }
            set { Set(ref _isTagged, value); }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get { return _isBusy; }
            set { Set(ref _isBusy, value); }
        }
        
    }
}
