﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace CogsExplorer.Modules.CustomVision.Views
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class StartPage : Page
    {
        public ServiceViewModel ViewModel { get; } = new ServiceViewModel();
        public StartPage()
        {
            this.InitializeComponent();
            this.Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            this.DataContext = this.ViewModel;

            Goo();
        }

        private async void Goo()
        {
           //var projects =  await Helpers.ProjectsHelper.GetProjectsAsync();

           // string projectId = projects[1].Id;

           // await Helpers.TrainingHelper.SetDefaultIterationAsync(projectId);


           //var allTags = await Helpers.TrainingHelper.GetTagsAsync(projectId);

           // //await Helpers.TrainingHelper.TrainProjectAsync(poroId);

           // List<string> tags = new List<string>() { "Tag One", "Tag Two" };


           // await Helpers.TrainingHelper.CreateTagsAsync(projectId, tags);

           // var images = await Helpers.PickerHelper.SelectImagesAsync();

           // List<byte[]> files = new List<byte[]>();

           // foreach(var image in images)
           // {
           //     files.Add(image.FileBytes);
           // }

           // await Helpers.TrainingHelper.UploadImagesAsync(projectId, files, tags);

        }

        

        private void OnImageSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            e.AddedItems.OfType<ImageInformation>().ForEach(f => f.IsSelected = true);
            e.RemovedItems.OfType<ImageInformation>().ForEach(f => f.IsSelected = false);
        }
    }
}
