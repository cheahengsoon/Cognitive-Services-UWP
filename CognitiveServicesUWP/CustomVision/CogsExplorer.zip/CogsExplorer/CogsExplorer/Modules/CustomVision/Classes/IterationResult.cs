﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.CustomVision
{
    
    public class IterationResult
    {
        public string Id { get; set; }
        public string ProjectId { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public DateTime Created { get; set; }
        public object LastModified { get; set; }
        public DateTime TrainedAt { get; set; }
        public bool IsDefault { get; set; }
        public string TrainedWithDomainId { get; set; }
        public bool Exportable { get; set; }
    }

}
