﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.CustomVision
{   
    public class TaggedImageInfo
    {
        public string Id { get; set; }
        public DateTime Created { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public string ImageUri { get; set; }
        public string ThumbnailUri { get; set; }
        public Label[] Labels { get; set; }
        public object Predictions { get; set; }        
    }

    public class Label
    {
        public string LabelId { get; set; }
        public DateTime Created { get; set; }
        public string TagId { get; set; }
    }

}
