﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.CustomVision
{

    public class ProjectInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public object Description { get; set; }
        public string CurrentIterationId { get; set; }
        public DateTime Created { get; set; }
        public DateTime LastModified { get; set; }
        public Settings Settings { get; set; }
        public string ThumbnailUri { get; set; }
    }

    public class Settings
    {
        public string DomainId { get; set; }
        public string Classification { get; set; }
        public bool UseNegativeSet { get; set; }
    }


}
