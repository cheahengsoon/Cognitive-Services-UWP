﻿using CogsExplorer.Common;
using CogsExplorer.Helpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace CogsExplorer.Modules.CustomVision
{
    public class ServiceViewModel : ObservableBase
    {
        public ServiceViewModel()
        {
            BrowseForImagesCommand = new RelayCommand(async () => { await BrowseForImagesAsync(); });
            AddNewTagCommand = new RelayCommand(async () => { await StartAddNewTagAsync(); });
            UploadImagesCommand = new RelayCommand(async () => { await StartUploadImagesAsync(); });
            BrowseForImageCommand = new RelayCommand(async () => { await BrowseForImageAsync(); });

            RefreshCurrentProject();
        }

        public async Task<int> BrowseForImageAsync()
        {
            this.IsBusy = true;

            var image = await Helpers.PickerHelper.SelectImageAsync();

            image.Url = await Helpers.StorageHelper.SaveToTemporaryFileAsync("CustomVision", image.DisplayName, image.FileBytes);

            this.SelectedImage.PredictionsLabel = string.Empty;
            this.SelectedImage.IsBusy = true;
            this.SelectedImage.DisplayName = image.DisplayName;
            this.SelectedImage.FileBytes = image.FileBytes;
            this.SelectedImage.Url = image.Url;
            this.SelectedImage.IsSelected = false;

            var predictions = await Helpers.PredictionHelper.GetImagePredictionsAsync(this.SelectedProject.Id, image.FileBytes);

            this.SelectedImage.Predictions.Clear();
            this.SelectedImage.PredictionsLabel = string.Empty;

            if (predictions.Count > 2)
            {

                foreach (var prediction in predictions.Take(3))
                {
                    this.SelectedImage.Predictions.Add(prediction);
                    this.SelectedImage.PredictionsLabel += "\r\n" + $"{prediction.Tag}: {prediction.Probablity.ToString("P0").Replace(" ", "")}";
                }

                this.SelectedImage.PredictionsLabel += "\r\n";
            }
            else
            {
                this.SelectedImage.Predictions.Add(new PredictionInformation()
                {
                    Probablity = 0.0,
                    Tag = "",
                });

                this.SelectedImage.PredictionsLabel = "(image not recognized)";
            }

            this.SelectedImage.IsBusy = false;
            this.IsBusy = false;

            return 1;

        }

        public async Task StartUploadImagesAsync()
        {
            this.IsBusy = true;

            List<byte[]> selectedImages = new List<byte[]>();

            foreach (var image in this.CurrentImages.Where(w => w.IsSelected))
            {
                selectedImages.Add(image.FileBytes);
            }

            await Helpers.TrainingHelper.UploadImagesAsync(this.SelectedProject.Id, selectedImages, this.AllTags.Where(w => w.IsSelected).Select(s => s.Id));

            await Helpers.TrainingHelper.TrainProjectAsync(this.SelectedProject.Id);

            await Helpers.TrainingHelper.SetDefaultIterationAsync(this.SelectedProject.Id);

            this.IsBusy = false;

            //RefreshTaggedImages();

            return;
        }

        private async void RefreshCurrentProject()
        {
            this.IsBusy = true;

            this.AllProjects.Clear();

            var allProjects = await Helpers.ProjectsHelper.GetProjectsAsync();

            foreach (var project in allProjects)
            {
                this.AllProjects.Add(project);
            }

            this.SelectedProject = this.AllProjects.FirstOrDefault();

            this.IsBusy = false;

            RefreshTags();
        }

        public async Task StartAddNewTagAsync()
        {
            this.IsBusy = true;

            await Helpers.TrainingHelper.CreateTagsAsync(this.SelectedProject.Id, new List<string>() { this.NewTagDisplayName });

            this.IsBusy = false;

            RefreshTags();

            return;
        }

        private async void RefreshTags()
        {
            this.IsBusy = true;

            this.AllTags.Clear();

            var tags = await Helpers.TrainingHelper.GetTagsAsync(this.SelectedProject.Id);

            foreach (var tag in tags)
            {
                tag.IsSelected = false;

                this.AllTags.Add(tag);
            }

            RefreshTaggedImages();

            this.IsBusy = false;
        }

        private async void RefreshTaggedImages()
        {
            var taggedImages = await Helpers.TrainingHelper.GetTaggedImagesAsync(this.SelectedProject.Id, this.AllTags);

            this.CurrentImages.Clear();

            foreach (var image in taggedImages)
            {
                foreach (var prediction in image.Predictions.Take(3))
                {
                    image.PredictionsLabel += "\r\n" + $"{prediction.Tag}: {prediction.Probablity.ToString("P0").Replace(" ", "")}";
                }

                image.PredictionsLabel += "\r\n";

                this.CurrentImages.Add(image);
            }
        }

        public ICommand BrowseForImagesCommand { get; private set; }
        public ICommand UploadImagesCommand { get; private set; }
        public ICommand AddNewTagCommand { get; private set; }
        public ICommand BrowseForImageCommand { get; private set; }

        private ImageInformation _selectedImage = new ImageInformation();
        public ImageInformation SelectedImage 
        {
            get { return _selectedImage; }
            set { Set(ref _selectedImage, value); }
        }

        private ObservableCollection<ImageInformation> _currentImages = new ObservableCollection<ImageInformation>();
        public ObservableCollection<ImageInformation> CurrentImages
        {
            get { return _currentImages; }
            set { Set(ref _currentImages, value); }
        }

        private ObservableCollection<ProjectInformation> _allProjects = new ObservableCollection<ProjectInformation>();
        public ObservableCollection<ProjectInformation> AllProjects
        {
            get { return _allProjects; }
            set { Set(ref _allProjects, value); }
        }

        private ObservableCollection<TagInformation> _allTags = new ObservableCollection<TagInformation>();
        public ObservableCollection<TagInformation> AllTags
        {
            get { return _allTags; }
            set { Set(ref _allTags, value); }
        }
        
        private ProjectInformation _selectedProject;
        public ProjectInformation SelectedProject
        {
            get { return _selectedProject; }
            set { Set(ref _selectedProject, value); }
        }

        private string _newTagDisplayName;
        public string NewTagDisplayName
        {
            get { return _newTagDisplayName; }
            set { Set(ref _newTagDisplayName, value); }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get { return _isBusy; }
            set { Set(ref _isBusy, value); }
        }
        
        public async Task<int> BrowseForImagesAsync()
        {
            this.IsBusy = true;

            var images = await Helpers.PickerHelper.SelectImagesAsync();

            foreach (var image in images)
            {
                image.Url = await Helpers.StorageHelper.SaveToTemporaryFileAsync("CustomVision", image.DisplayName, image.FileBytes);
                
                this.CurrentImages.Insert(0, image);
            }

            this.IsBusy = false;

            return images.Count;

        }

         
    }
}
