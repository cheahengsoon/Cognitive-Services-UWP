﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.CustomVision.Common
{
    public class CoreConstants
    {
        public static string CustomVisionApiTrainingKey = "CustomVisionApiTrainingKey";
        public static string CustomVisionApiPredictionKey = "CustomVisionApiPredictionKey";
    }
}
