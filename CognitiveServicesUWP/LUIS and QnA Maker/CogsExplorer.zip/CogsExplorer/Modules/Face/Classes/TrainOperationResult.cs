﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.Face
{
    public class TrainOperationResult
    {
        public string status { get; set; }

    }
}
