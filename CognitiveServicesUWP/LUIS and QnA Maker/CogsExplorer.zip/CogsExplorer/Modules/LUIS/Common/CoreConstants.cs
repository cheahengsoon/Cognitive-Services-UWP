﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.LUIS.Common
{
    public class CoreConstants
    {
        public static string QnAApiSubscriptionKey = "QnAApiSubscriptionKey";
        public static string LuisApiSubscriptionKey = "LuisApiSubscriptionKey";
        public static string LuisApplicationId = "LuisApplicationId";
    }
}
