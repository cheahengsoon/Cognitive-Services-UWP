﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.Emotion.Common
{
    public class CoreConstants
    {
        public static string EmotionApiSubscriptionKey = "YOUR_EMOTION_API_KEY";
        public static string TextAnalyticsSubscriptionKey = "YOUR_TEXT_ANALYTICS_API_KEY";
        public static string SearchSubscriptionKey = "YOUR_SEARCH_API_KEY";
    }
}
