﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.Emotion
{ 

    public class DetectOperationResult
    {
        public string status { get; set; }

    }
}
