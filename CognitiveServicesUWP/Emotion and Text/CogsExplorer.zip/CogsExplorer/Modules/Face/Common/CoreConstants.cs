﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CogsExplorer.Modules.Face.Common
{
    public class CoreConstants
    {
        public static string FaceApiSubscriptionKey = "YOUR_FACE_API_KEY";
    }
}
